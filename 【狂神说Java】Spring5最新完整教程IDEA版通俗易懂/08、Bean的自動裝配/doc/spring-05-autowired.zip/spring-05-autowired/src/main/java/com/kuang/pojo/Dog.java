package com.kuang.pojo;

public class Dog {
    public void shout(){
        System.out.println("wang");
    }
}
